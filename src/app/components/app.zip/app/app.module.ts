import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './components/app.component';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from './components/navbar/navbar.component';
import { IndexComponent } from './components/index/index.component';
import { EntradasComponent } from './components/entradas/entradas.component';
import { CadastroComponent } from './components/cadastro/cadastro.component';


@NgModule({
  declarations: [
    // AppComponent,
    // CadastroComponent,
    // NavbarComponent,
    // IndexComponent,
    // EntradasComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
  ],
  providers: [],
  // bootstrap: [AppComponent]
})
export class AppModule { }
